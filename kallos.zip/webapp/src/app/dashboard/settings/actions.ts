'use server'

import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function getSettingsData() {
  const session = await getServerSession(authOptions)
  if (!session?.user) throw new Error("Non autorizzato")

  // @ts-ignore
  const userId = session.user.id

  const user = await prisma.user.findUnique({
    where: { id: userId }
  })

  const member = await prisma.workspaceMember.findFirst({
    where: { user_id: userId }
  })

  let settings = null
  if (member) {
    settings = await prisma.impostazioniSalone.findUnique({
      where: { workspace_id: member.workspace_id }
    })
  }

  return { user, settings, workspaceId: member?.workspace_id }
}

export async function updateSettings(data: {
  nome: string,
  cognome: string,
  qualifica: string,
  specializzazione: string,
  workspaceId: string | null,
  moduloParrucchieria: boolean,
  moduloEstetica: boolean
}) {
  const session = await getServerSession(authOptions)
  if (!session?.user) throw new Error("Non autorizzato")

  // @ts-ignore
  const userId = session.user.id

  // Update user
  await prisma.user.update({
    where: { id: userId },
    data: {
      name: `${data.nome} ${data.cognome}`.trim(),
      qualifica: data.qualifica,
      specializzazione: data.specializzazione
    }
  })

  if (data.workspaceId) {
    const existingSettings = await prisma.impostazioniSalone.findUnique({
      where: { workspace_id: data.workspaceId }
    })

    if (existingSettings) {
      await prisma.impostazioniSalone.update({
        where: { workspace_id: data.workspaceId },
        data: {
          modulo_parrucchieria: data.moduloParrucchieria,
          modulo_estetica: data.moduloEstetica
        }
      })
    } else {
      await prisma.impostazioniSalone.create({
        data: {
          workspace_id: data.workspaceId,
          modulo_parrucchieria: data.moduloParrucchieria,
          modulo_estetica: data.moduloEstetica
        }
      })
    }
  }

  return { success: true }
}
